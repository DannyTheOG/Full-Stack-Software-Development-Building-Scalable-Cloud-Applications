const UserModel = require("../../models/userModel");
const UserSessionModel = require("../../models/userSessionModel");

const findUserByUsername = async (username) => {
  /*WRITE YOUR CODE HERE */
};

const createUser = async (userData) => {
  /*WRITE YOUR CODE HERE */
};

const findUserById = async (id) => {
  /*WRITE YOUR CODE HERE */
};

const findActiveUsers = async () => {
  /*WRITE YOUR CODE HERE */
};

const findActiveUserSession = async (userId, sessionToken) => {
  /*WRITE YOUR CODE HERE */
};

const createUserSession = async (sessionData) => {
  /*WRITE YOUR CODE HERE */
};

const deactivateUserSession = async (userSessionObject) => {
  /*WRITE YOUR CODE HERE */
};

const updateUser = async (id, updateData) => {
  try {
    return await UserModel.findByIdAndUpdate(id, updateData, { new: true });
  } catch (err) {
    throw new Error(`Error while updating user: ${err.message}`);
  }
};

const deleteUser = async (id) => {
  try {
    return await UserModel.findByIdAndUpdate(id, { isActive: false });
  } catch (err) {
    throw new Error(`Error while deleting user: ${err.message}`);
  }
};

module.exports = {
  findUserByUsername,
  createUser,
  findUserById,
  updateUser,
  deleteUser,
  findActiveUsers,
  findActiveUserSession,
  createUserSession,
  deactivateUserSession,
};
