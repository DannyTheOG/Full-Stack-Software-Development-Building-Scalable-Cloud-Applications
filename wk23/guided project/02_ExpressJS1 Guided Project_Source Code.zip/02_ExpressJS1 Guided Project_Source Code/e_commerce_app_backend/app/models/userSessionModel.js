const mongoose = require('mongoose');
const { default: UserModel } = require('./userModel');

const userSessionSchema = mongoose.Schema({
    /*WRITE YOUR CODE HERE */
});

const UserSessionModel = mongoose.model('userSession', userSessionSchema);

module.exports = UserSessionModel;