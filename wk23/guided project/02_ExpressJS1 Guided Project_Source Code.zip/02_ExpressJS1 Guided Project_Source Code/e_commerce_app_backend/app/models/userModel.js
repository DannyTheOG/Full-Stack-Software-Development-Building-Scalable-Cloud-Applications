const mongoose = require('mongoose')

const userSchema = mongoose.Schema(
    /*WRITE YOUR CODE HERE */
);

const UserModel = mongoose.model('user', userSchema);

module.exports = UserModel;