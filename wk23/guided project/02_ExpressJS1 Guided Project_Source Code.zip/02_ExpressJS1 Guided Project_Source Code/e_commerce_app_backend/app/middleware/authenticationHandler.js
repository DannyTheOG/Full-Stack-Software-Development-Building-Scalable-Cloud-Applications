const jwt = require("jsonwebtoken");
const asyncHandler = require("express-async-handler");
const UserModel = require("../models/userModel");
const UserSessionModel = require("../models/userSessionModel");
const { JWT_SECRET_KEY } = require("../constants");

const auth = asyncHandler(async (req, res, next) => {
  /*WRITE YOUR CODE HERE */
});

const isAdmin = asyncHandler(async (req, res, next) => {
  /*WRITE YOUR CODE HERE */
});

module.exports = {
  auth,
  isAdmin,
};
