// Question 1: Declare an object named "person" with properties "name", "age", and "city" and set their respective values to "John", 30, and "New York".

// Question 2: Declare an object named "book" with properties "title", "author", and "year" and set their respective values to "The Great Gatsby", "F. Scott Fitzgerald", and 1925. Access the "author" property and store its value in a variable called "authorName".

// Question 3: Declare an object named "employee" with properties "name", "age", and "city". Delete the "city" property from the object.

// Question 4: Create a "game" object having following information - 
// gamingPlatform as "Roblox", minimumAge as 10, programmingLanguage as "Lua". 
// Display object information.
// Change the value of minimumAge as 12. 
// Display object information again.

  
// Question 5: Given an array "employees" of Javascript objects. Write a code to iterate through
// each of these objects using forEach method and extract first name and last name of each employee.
  
  
// Question 6: Declare an object named "toy" with an empty object as its initial value. 
// Add the properties "name" and "category" with values "Super Space Rocket" and "Action Figures & Playsets" respectively.
  
  
// Question 7: Given an array of employees objects, define a function to find employee with the least salary.
  